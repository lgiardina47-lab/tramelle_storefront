"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20260112153000 = void 0;
const migrations_1 = require("@medusajs/framework/mikro-orm/migrations");
class Migration20260112153000 extends migrations_1.Migration {
    async up() {
        this.addSql(`
      CREATE TABLE IF NOT EXISTS "blog_post" (
        "id" text PRIMARY KEY,
        "title" text NOT NULL,
        "handle" text NOT NULL,
        "status" text NOT NULL DEFAULT 'draft',
        "thumbnail" text NULL,
        "short_description" text NULL,
        "read_time" integer NOT NULL DEFAULT 0,
        "tags" jsonb NULL,
        "body" text NULL,
        "created_by" text NULL,
        "read_count" integer NOT NULL DEFAULT 0,
        "metadata" jsonb NULL,
        "created_at" timestamptz NOT NULL DEFAULT now(),
        "updated_at" timestamptz NOT NULL DEFAULT now(),
        "deleted_at" timestamptz NULL
      );
    `);
        this.addSql(`
      CREATE UNIQUE INDEX IF NOT EXISTS "IDX_blog_post_handle"
      ON "blog_post" ("handle") WHERE "deleted_at" IS NULL;
    `);
        this.addSql(`
      CREATE INDEX IF NOT EXISTS "IDX_blog_post_deleted_at"
      ON "blog_post" ("deleted_at") WHERE "deleted_at" IS NULL;
    `);
    }
    async down() {
        this.addSql(`DROP TABLE IF EXISTS "blog_post";`);
    }
}
exports.Migration20260112153000 = Migration20260112153000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNjAxMTIxNTMwMDAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9ibG9nL21pZ3JhdGlvbnMvTWlncmF0aW9uMjAyNjAxMTIxNTMwMDAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEseUVBQW9FO0FBRXBFLE1BQWEsdUJBQXdCLFNBQVEsc0JBQVM7SUFDbEQsS0FBSyxDQUFDLEVBQUU7UUFDSixJQUFJLENBQUMsTUFBTSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7S0FrQmYsQ0FBQyxDQUFBO1FBRUUsSUFBSSxDQUFDLE1BQU0sQ0FBQzs7O0tBR2YsQ0FBQyxDQUFBO1FBRUUsSUFBSSxDQUFDLE1BQU0sQ0FBQzs7O0tBR2YsQ0FBQyxDQUFBO0lBQ0YsQ0FBQztJQUVELEtBQUssQ0FBQyxJQUFJO1FBQ04sSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFBO0lBQ3BELENBQUM7Q0FDSjtBQXBDRCwwREFvQ0MifQ==