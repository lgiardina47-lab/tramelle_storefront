"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const post_1 = require("./models/post");
class BlogModuleService extends (0, utils_1.MedusaService)({
    Post: post_1.Post,
}) {
    constructor(container) {
        super(container);
        if (!container.manager) {
            throw new Error("EntityManager is not available in the container. " +
                "Ensure the plugin is properly registered in medusa-config.ts " +
                "and the database connection is configured.");
        }
        this.manager_ = container.manager;
    }
    async incrementReadCount(id) {
        const post = await this.retrievePost(id);
        await this.updatePosts({
            id,
            read_count: (post.read_count || 0) + 1,
        });
    }
}
exports.default = BlogModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2Jsb2cvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUF5RDtBQUV6RCx3Q0FBb0M7QUFVcEMsTUFBTSxpQkFBa0IsU0FBUSxJQUFBLHFCQUFhLEVBQUM7SUFDMUMsSUFBSSxFQUFKLFdBQUk7Q0FDUCxDQUFDO0lBR0UsWUFBWSxTQUErQjtRQUN2QyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFaEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNyQixNQUFNLElBQUksS0FBSyxDQUNYLG1EQUFtRDtnQkFDbkQsK0RBQStEO2dCQUMvRCw0Q0FBNEMsQ0FDL0MsQ0FBQTtRQUNMLENBQUM7UUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUE7SUFDckMsQ0FBQztJQUVELEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxFQUFVO1FBQy9CLE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUV4QyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUM7WUFDbkIsRUFBRTtZQUNGLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQztTQUN6QyxDQUFDLENBQUE7SUFDTixDQUFDO0NBQ0o7QUFFRCxrQkFBZSxpQkFBaUIsQ0FBQSJ9