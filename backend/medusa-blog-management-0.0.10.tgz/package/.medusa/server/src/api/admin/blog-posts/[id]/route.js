"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DELETE = exports.POST = exports.GET = void 0;
const utils_1 = require("@medusajs/framework/utils");
const blog_1 = require("../../../../modules/blog");
const validators_1 = require("../validators");
const GET = async (req, res) => {
    try {
        const blogModuleService = req.scope.resolve(blog_1.BLOG_MODULE);
        const { id } = req.params;
        if (!id) {
            res.status(400).json({
                message: "Post ID is required",
            });
            return;
        }
        const post = await blogModuleService.retrievePost(id);
        const response = { post: post };
        res.json(response);
    }
    catch (error) {
        if (error instanceof utils_1.MedusaError) {
            if (error.type === utils_1.MedusaError.Types.NOT_FOUND) {
                res.status(404).json({
                    message: "Blog post not found",
                });
                return;
            }
            res.status(Number(error.code) || 500).json({
                message: error.message,
                type: error.type,
            });
            return;
        }
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        res.status(500).json({
            message: "Failed to retrieve blog post",
            error: errorMessage,
        });
    }
};
exports.GET = GET;
const POST = async (req, res) => {
    try {
        const blogModuleService = req.scope.resolve(blog_1.BLOG_MODULE);
        const { id } = req.params;
        if (!id) {
            res.status(400).json({
                message: "Post ID is required",
            });
            return;
        }
        // Validate request body
        const validationResult = validators_1.UpdateBlogPostSchema.safeParse(req.body);
        if (!validationResult.success) {
            res.status(400).json({
                message: "Validation failed",
                errors: validationResult.error.errors,
            });
            return;
        }
        const validatedData = validationResult.data;
        // Convert tags array to Record for JSON field compatibility
        const updateData = {
            id,
            ...validatedData,
            tags: validatedData.tags !== undefined
                ? validatedData.tags
                : undefined,
        };
        const post = await blogModuleService.updatePosts(updateData);
        const response = {
            post: (Array.isArray(post) ? post[0] : post)
        };
        res.json(response);
    }
    catch (error) {
        if (error instanceof utils_1.MedusaError) {
            if (error.type === utils_1.MedusaError.Types.NOT_FOUND) {
                res.status(404).json({
                    message: "Blog post not found",
                });
                return;
            }
            res.status(Number(error.code) || 500).json({
                message: error.message,
                code: error.code,
            });
            return;
        }
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        res.status(500).json({
            message: "Failed to update blog post",
            error: errorMessage,
        });
    }
};
exports.POST = POST;
const DELETE = async (req, res) => {
    try {
        const blogModuleService = req.scope.resolve(blog_1.BLOG_MODULE);
        const { id } = req.params;
        if (!id) {
            res.status(400).json({
                message: "Post ID is required",
            });
            return;
        }
        await blogModuleService.deletePosts(id);
        const response = {
            id,
            object: "blog_post",
            deleted: true,
        };
        res.json(response);
    }
    catch (error) {
        if (error instanceof utils_1.MedusaError) {
            if (error.type === utils_1.MedusaError.Types.NOT_FOUND) {
                res.status(404).json({
                    message: "Blog post not found",
                });
                return;
            }
            res.status(Number(error.code) || 500).json({
                message: error.message,
                code: error.code,
            });
            return;
        }
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        res.status(500).json({
            message: "Failed to delete blog post",
            error: errorMessage,
        });
    }
};
exports.DELETE = DELETE;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2Jsb2ctcG9zdHMvW2lkXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxREFBdUQ7QUFDdkQsbURBQXNEO0FBRXRELDhDQUF5RTtBQUdsRSxNQUFNLEdBQUcsR0FBRyxLQUFLLEVBQ3BCLEdBQWtCLEVBQ2xCLEdBQW1CLEVBQ04sRUFBRTtJQUNmLElBQUksQ0FBQztRQUNELE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQW9CLGtCQUFXLENBQUMsQ0FBQTtRQUMzRSxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtRQUV6QixJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDTixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDakIsT0FBTyxFQUFFLHFCQUFxQjthQUNqQyxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1YsQ0FBQztRQUVELE1BQU0sSUFBSSxHQUFHLE1BQU0saUJBQWlCLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRXJELE1BQU0sUUFBUSxHQUFxQixFQUFFLElBQUksRUFBRSxJQUE4QixFQUFFLENBQUE7UUFDM0UsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUN0QixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksS0FBSyxZQUFZLG1CQUFXLEVBQUUsQ0FBQztZQUMvQixJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQzdDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUNqQixPQUFPLEVBQUUscUJBQXFCO2lCQUNqQyxDQUFDLENBQUE7Z0JBQ0YsT0FBTTtZQUNWLENBQUM7WUFDRCxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUN2QyxPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87Z0JBQ3RCLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTthQUNuQixDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1YsQ0FBQztRQUVELE1BQU0sWUFBWSxHQUFHLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQTtRQUM3RSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNqQixPQUFPLEVBQUUsOEJBQThCO1lBQ3ZDLEtBQUssRUFBRSxZQUFZO1NBQ3RCLENBQUMsQ0FBQTtJQUNOLENBQUM7QUFDTCxDQUFDLENBQUE7QUF4Q1ksUUFBQSxHQUFHLE9Bd0NmO0FBRU0sTUFBTSxJQUFJLEdBQUcsS0FBSyxFQUNyQixHQUFrQixFQUNsQixHQUFtQixFQUNOLEVBQUU7SUFDZixJQUFJLENBQUM7UUFDRCxNQUFNLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFvQixrQkFBVyxDQUFDLENBQUE7UUFDM0UsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7UUFFekIsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ04sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ2pCLE9BQU8sRUFBRSxxQkFBcUI7YUFDakMsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNWLENBQUM7UUFFRCx3QkFBd0I7UUFDeEIsTUFBTSxnQkFBZ0IsR0FBRyxpQ0FBb0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBRWpFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM1QixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDakIsT0FBTyxFQUFFLG1CQUFtQjtnQkFDNUIsTUFBTSxFQUFFLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxNQUFNO2FBQ3hDLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDVixDQUFDO1FBRUQsTUFBTSxhQUFhLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFBO1FBRTNDLDREQUE0RDtRQUM1RCxNQUFNLFVBQVUsR0FBRztZQUNmLEVBQUU7WUFDRixHQUFHLGFBQWE7WUFDaEIsSUFBSSxFQUFFLGFBQWEsQ0FBQyxJQUFJLEtBQUssU0FBUztnQkFDbEMsQ0FBQyxDQUFFLGFBQWEsQ0FBQyxJQUEyQztnQkFDNUQsQ0FBQyxDQUFDLFNBQVM7U0FDbEIsQ0FBQTtRQUVELE1BQU0sSUFBSSxHQUFHLE1BQU0saUJBQWlCLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFBO1FBRTVELE1BQU0sUUFBUSxHQUFxQjtZQUMvQixJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBMkI7U0FDekUsQ0FBQTtRQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDdEIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLEtBQUssWUFBWSxtQkFBVyxFQUFFLENBQUM7WUFDL0IsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLG1CQUFXLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUM3QyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDakIsT0FBTyxFQUFFLHFCQUFxQjtpQkFDakMsQ0FBQyxDQUFBO2dCQUNGLE9BQU07WUFDVixDQUFDO1lBQ0QsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDdkMsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUN0QixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7YUFDbkIsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNWLENBQUM7UUFFRCxNQUFNLFlBQVksR0FBRyxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUE7UUFDN0UsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDakIsT0FBTyxFQUFFLDRCQUE0QjtZQUNyQyxLQUFLLEVBQUUsWUFBWTtTQUN0QixDQUFDLENBQUE7SUFDTixDQUFDO0FBQ0wsQ0FBQyxDQUFBO0FBaEVZLFFBQUEsSUFBSSxRQWdFaEI7QUFFTSxNQUFNLE1BQU0sR0FBRyxLQUFLLEVBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CLEVBQ04sRUFBRTtJQUNmLElBQUksQ0FBQztRQUNELE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQW9CLGtCQUFXLENBQUMsQ0FBQTtRQUMzRSxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtRQUV6QixJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDTixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDakIsT0FBTyxFQUFFLHFCQUFxQjthQUNqQyxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1YsQ0FBQztRQUVELE1BQU0saUJBQWlCLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRXZDLE1BQU0sUUFBUSxHQUEyQjtZQUNyQyxFQUFFO1lBQ0YsTUFBTSxFQUFFLFdBQVc7WUFDbkIsT0FBTyxFQUFFLElBQUk7U0FDaEIsQ0FBQTtRQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDdEIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLEtBQUssWUFBWSxtQkFBVyxFQUFFLENBQUM7WUFDL0IsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLG1CQUFXLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUM3QyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDakIsT0FBTyxFQUFFLHFCQUFxQjtpQkFDakMsQ0FBQyxDQUFBO2dCQUNGLE9BQU07WUFDVixDQUFDO1lBQ0QsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDdkMsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUN0QixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7YUFDbkIsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNWLENBQUM7UUFFRCxNQUFNLFlBQVksR0FBRyxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUE7UUFDN0UsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDakIsT0FBTyxFQUFFLDRCQUE0QjtZQUNyQyxLQUFLLEVBQUUsWUFBWTtTQUN0QixDQUFDLENBQUE7SUFDTixDQUFDO0FBQ0wsQ0FBQyxDQUFBO0FBNUNZLFFBQUEsTUFBTSxVQTRDbEIifQ==