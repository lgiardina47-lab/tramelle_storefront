"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = exports.GET = void 0;
const utils_1 = require("@medusajs/framework/utils");
const blog_1 = require("../../../modules/blog");
const validators_1 = require("./validators");
const GET = async (req, res) => {
    try {
        const blogModuleService = req.scope.resolve(blog_1.BLOG_MODULE);
        const { skip, take } = req.query;
        const skipNum = skip ? parseInt(skip, 10) : 0;
        const takeNum = take ? parseInt(take, 10) : 20;
        if (isNaN(skipNum) || skipNum < 0) {
            res.status(400).json({
                message: "Invalid skip parameter",
            });
            return;
        }
        if (isNaN(takeNum) || takeNum < 1 || takeNum > 100) {
            res.status(400).json({
                message: "Invalid take parameter. Must be between 1 and 100",
            });
            return;
        }
        const [posts, count] = await blogModuleService.listAndCountPosts({}, {
            skip: skipNum,
            take: takeNum,
            order: { created_at: "DESC" },
        });
        const response = {
            posts: posts,
            count,
            limit: takeNum,
            offset: skipNum,
        };
        res.json(response);
    }
    catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        res.status(500).json({
            message: "Failed to retrieve blog posts",
            error: errorMessage,
        });
    }
};
exports.GET = GET;
const POST = async (req, res) => {
    try {
        const blogModuleService = req.scope.resolve(blog_1.BLOG_MODULE);
        // Validate request body
        const validationResult = validators_1.CreateBlogPostSchema.safeParse(req.body);
        if (!validationResult.success) {
            res.status(400).json({
                message: "Validation failed",
                errors: validationResult.error.errors,
            });
            return;
        }
        const validatedData = validationResult.data;
        // Convert tags array to Record for JSON field compatibility
        const createData = {
            ...validatedData,
            tags: validatedData.tags !== undefined
                ? validatedData.tags
                : undefined,
        };
        const post = await blogModuleService.createPosts(createData);
        const response = {
            post: (Array.isArray(post) ? post[0] : post)
        };
        res.json(response);
    }
    catch (error) {
        if (error instanceof utils_1.MedusaError) {
            res.status(Number(error.code) || 500).json({
                message: error.message,
                code: error.code,
            });
            return;
        }
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        res.status(500).json({
            message: "Failed to create blog post",
            error: errorMessage,
        });
    }
};
exports.POST = POST;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2Jsb2ctcG9zdHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EscURBQXVEO0FBQ3ZELGdEQUFtRDtBQUVuRCw2Q0FBbUQ7QUFHNUMsTUFBTSxHQUFHLEdBQUcsS0FBSyxFQUNwQixHQUFrQixFQUNsQixHQUFtQixFQUNOLEVBQUU7SUFDZixJQUFJLENBQUM7UUFDRCxNQUFNLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFvQixrQkFBVyxDQUFDLENBQUE7UUFFM0UsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO1FBRWhDLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3ZELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBRXhELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE9BQU8sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNoQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDakIsT0FBTyxFQUFFLHdCQUF3QjthQUNwQyxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1YsQ0FBQztRQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE9BQU8sR0FBRyxDQUFDLElBQUksT0FBTyxHQUFHLEdBQUcsRUFBRSxDQUFDO1lBQ2pELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNqQixPQUFPLEVBQUUsbURBQW1EO2FBQy9ELENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDVixDQUFDO1FBRUQsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLGlCQUFpQixDQUFDLGlCQUFpQixDQUM1RCxFQUFFLEVBQ0Y7WUFDSSxJQUFJLEVBQUUsT0FBTztZQUNiLElBQUksRUFBRSxPQUFPO1lBQ2IsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRTtTQUNoQyxDQUNKLENBQUE7UUFFRCxNQUFNLFFBQVEsR0FBeUI7WUFDbkMsS0FBSyxFQUFFLEtBQWlDO1lBQ3hDLEtBQUs7WUFDTCxLQUFLLEVBQUUsT0FBTztZQUNkLE1BQU0sRUFBRSxPQUFPO1NBQ2xCLENBQUE7UUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQ3RCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2IsTUFBTSxZQUFZLEdBQUcsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFBO1FBQzdFLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ2pCLE9BQU8sRUFBRSwrQkFBK0I7WUFDeEMsS0FBSyxFQUFFLFlBQVk7U0FDdEIsQ0FBQyxDQUFBO0lBQ04sQ0FBQztBQUNMLENBQUMsQ0FBQTtBQWxEWSxRQUFBLEdBQUcsT0FrRGY7QUFFTSxNQUFNLElBQUksR0FBRyxLQUFLLEVBQ3JCLEdBQWtCLEVBQ2xCLEdBQW1CLEVBQ04sRUFBRTtJQUNmLElBQUksQ0FBQztRQUNELE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQW9CLGtCQUFXLENBQUMsQ0FBQTtRQUUzRSx3QkFBd0I7UUFDeEIsTUFBTSxnQkFBZ0IsR0FBRyxpQ0FBb0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBRWpFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM1QixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDakIsT0FBTyxFQUFFLG1CQUFtQjtnQkFDNUIsTUFBTSxFQUFFLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxNQUFNO2FBQ3hDLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDVixDQUFDO1FBRUQsTUFBTSxhQUFhLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFBO1FBRTNDLDREQUE0RDtRQUM1RCxNQUFNLFVBQVUsR0FBRztZQUNmLEdBQUcsYUFBYTtZQUNoQixJQUFJLEVBQUUsYUFBYSxDQUFDLElBQUksS0FBSyxTQUFTO2dCQUNsQyxDQUFDLENBQUUsYUFBYSxDQUFDLElBQTJDO2dCQUM1RCxDQUFDLENBQUMsU0FBUztTQUNsQixDQUFBO1FBRUQsTUFBTSxJQUFJLEdBQUcsTUFBTSxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUE7UUFFNUQsTUFBTSxRQUFRLEdBQXFCO1lBQy9CLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUEyQjtTQUN6RSxDQUFBO1FBQ0QsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUN0QixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksS0FBSyxZQUFZLG1CQUFXLEVBQUUsQ0FBQztZQUMvQixHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUN2QyxPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87Z0JBQ3RCLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTthQUNuQixDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1YsQ0FBQztRQUVELE1BQU0sWUFBWSxHQUFHLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQTtRQUM3RSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNqQixPQUFPLEVBQUUsNEJBQTRCO1lBQ3JDLEtBQUssRUFBRSxZQUFZO1NBQ3RCLENBQUMsQ0FBQTtJQUNOLENBQUM7QUFDTCxDQUFDLENBQUE7QUFqRFksUUFBQSxJQUFJLFFBaURoQiJ9