"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const utils_1 = require("@medusajs/framework/utils");
const blog_1 = require("../../../../modules/blog");
const GET = async (req, res) => {
    try {
        const blogModuleService = req.scope.resolve(blog_1.BLOG_MODULE);
        const { id } = req.params;
        if (!id) {
            res.status(400).json({
                message: "Post ID is required",
            });
            return;
        }
        const post = await blogModuleService.retrievePost(id);
        // Only show published posts in storefront
        if (post.status !== "published") {
            res.status(404).json({
                message: "Blog post not found",
            });
            return;
        }
        // Increment read count asynchronously (don't await to avoid blocking response)
        blogModuleService.incrementReadCount(id).catch((error) => {
            // Log error but don't fail the request
            console.error("Failed to increment read count:", error);
        });
        const response = { post: post };
        res.json(response);
    }
    catch (error) {
        if (error instanceof utils_1.MedusaError) {
            if (error.type === utils_1.MedusaError.Types.NOT_FOUND) {
                res.status(404).json({
                    message: "Blog post not found",
                });
                return;
            }
            res.status(Number(error.code) || 500).json({
                message: error.message,
                code: error.code,
            });
            return;
        }
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        res.status(500).json({
            message: "Failed to retrieve blog post",
            error: errorMessage,
        });
    }
};
exports.GET = GET;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2Jsb2ctcG9zdHMvW2lkXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxREFBdUQ7QUFDdkQsbURBQXNEO0FBSS9DLE1BQU0sR0FBRyxHQUFHLEtBQUssRUFDcEIsR0FBa0IsRUFDbEIsR0FBbUIsRUFDTixFQUFFO0lBQ2YsSUFBSSxDQUFDO1FBQ0QsTUFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBb0Isa0JBQVcsQ0FBQyxDQUFBO1FBQzNFLE1BQU0sRUFBRSxFQUFFLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO1FBRXpCLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNOLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNqQixPQUFPLEVBQUUscUJBQXFCO2FBQ2pDLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDVixDQUFDO1FBRUQsTUFBTSxJQUFJLEdBQUcsTUFBTSxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUE7UUFFckQsMENBQTBDO1FBQzFDLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUM5QixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDakIsT0FBTyxFQUFFLHFCQUFxQjthQUNqQyxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1YsQ0FBQztRQUVELCtFQUErRTtRQUMvRSxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNyRCx1Q0FBdUM7WUFDdkMsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUMzRCxDQUFDLENBQUMsQ0FBQTtRQUVGLE1BQU0sUUFBUSxHQUFxQixFQUFFLElBQUksRUFBRSxJQUE4QixFQUFFLENBQUE7UUFDM0UsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUN0QixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNiLElBQUksS0FBSyxZQUFZLG1CQUFXLEVBQUUsQ0FBQztZQUMvQixJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQzdDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUNqQixPQUFPLEVBQUUscUJBQXFCO2lCQUNqQyxDQUFDLENBQUE7Z0JBQ0YsT0FBTTtZQUNWLENBQUM7WUFDRCxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUN2QyxPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87Z0JBQ3RCLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTthQUNuQixDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1YsQ0FBQztRQUVELE1BQU0sWUFBWSxHQUFHLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQTtRQUM3RSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNqQixPQUFPLEVBQUUsOEJBQThCO1lBQ3ZDLEtBQUssRUFBRSxZQUFZO1NBQ3RCLENBQUMsQ0FBQTtJQUNOLENBQUM7QUFDTCxDQUFDLENBQUE7QUF0RFksUUFBQSxHQUFHLE9Bc0RmIn0=