"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getClientRequest = exports.buildHeaders = exports.normalizeBaseUrl = void 0;
const normalizeBaseUrl = (baseUrl) => {
    if (!baseUrl) {
        return "";
    }
    return baseUrl.endsWith("/") ? baseUrl.slice(0, -1) : baseUrl;
};
exports.normalizeBaseUrl = normalizeBaseUrl;
const buildHeaders = (options) => {
    const headers = {
        "Content-Type": "application/json",
        ...(options.headers ?? {}),
    };
    const hasPublishableHeader = Object.keys(headers).some((key) => key.toLowerCase() === "x-publishable-api-key");
    if (options.publishableApiKey && !hasPublishableHeader) {
        headers["x-publishable-api-key"] = options.publishableApiKey;
    }
    return headers;
};
exports.buildHeaders = buildHeaders;
const getClientRequest = (client) => {
    if (!client) {
        return undefined;
    }
    if ("request" in client && typeof client.request === "function") {
        return client.request.bind(client);
    }
    if ("client" in client && typeof client.client?.request === "function") {
        return client.client.request.bind(client.client);
    }
    return undefined;
};
exports.getClientRequest = getClientRequest;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS1jbGllbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvaGVscGVycy9iYXNlLWNsaWVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFvQ08sTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLE9BQWdCLEVBQUUsRUFBRTtJQUNqRCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDWCxPQUFPLEVBQUUsQ0FBQTtJQUNiLENBQUM7SUFDRCxPQUFPLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQTtBQUNqRSxDQUFDLENBQUE7QUFMWSxRQUFBLGdCQUFnQixvQkFLNUI7QUFFTSxNQUFNLFlBQVksR0FBRyxDQUFDLE9BQStCLEVBQUUsRUFBRTtJQUM1RCxNQUFNLE9BQU8sR0FBMkI7UUFDcEMsY0FBYyxFQUFFLGtCQUFrQjtRQUNsQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7S0FDN0IsQ0FBQTtJQUVELE1BQU0sb0JBQW9CLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQ2xELENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEtBQUssdUJBQXVCLENBQ3pELENBQUE7SUFFRCxJQUFJLE9BQU8sQ0FBQyxpQkFBaUIsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDckQsT0FBTyxDQUFDLHVCQUF1QixDQUFDLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFBO0lBQ2hFLENBQUM7SUFFRCxPQUFPLE9BQU8sQ0FBQTtBQUNsQixDQUFDLENBQUE7QUFmWSxRQUFBLFlBQVksZ0JBZXhCO0FBRU0sTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLE1BQXlCLEVBQUUsRUFBRTtJQUMxRCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDVixPQUFPLFNBQVMsQ0FBQTtJQUNwQixDQUFDO0lBRUQsSUFBSSxTQUFTLElBQUksTUFBTSxJQUFJLE9BQU8sTUFBTSxDQUFDLE9BQU8sS0FBSyxVQUFVLEVBQUUsQ0FBQztRQUM5RCxPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ3RDLENBQUM7SUFFRCxJQUFJLFFBQVEsSUFBSSxNQUFNLElBQUksT0FBTyxNQUFNLENBQUMsTUFBTSxFQUFFLE9BQU8sS0FBSyxVQUFVLEVBQUUsQ0FBQztRQUNyRSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDcEQsQ0FBQztJQUVELE9BQU8sU0FBUyxDQUFBO0FBQ3BCLENBQUMsQ0FBQTtBQWRZLFFBQUEsZ0JBQWdCLG9CQWM1QiJ9