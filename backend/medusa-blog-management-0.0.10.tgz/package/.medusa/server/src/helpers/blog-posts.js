"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBlogMetadata = exports.getBlogPost = exports.getBlogList = void 0;
const base_client_1 = require("./base-client");
const DEFAULT_ENDPOINT = "/store/blog-posts";
const getBlogList = async (params = {}, options = {}) => {
    const endpoint = params.endpoint || DEFAULT_ENDPOINT;
    const query = new URLSearchParams();
    if (params.skip)
        query.append("skip", params.skip.toString());
    if (params.take)
        query.append("take", params.take.toString());
    const queryString = query.toString();
    const path = queryString ? `${endpoint}?${queryString}` : endpoint;
    const clientRequest = (0, base_client_1.getClientRequest)(options.client);
    if (clientRequest) {
        const headers = (0, base_client_1.buildHeaders)(options);
        return (await clientRequest(path, {
            method: "GET",
            headers,
        }));
    }
    const fetchImpl = options.fetchImpl ?? globalThis.fetch;
    const url = `${(0, base_client_1.normalizeBaseUrl)(options.baseUrl)}${path}`;
    const headers = (0, base_client_1.buildHeaders)(options);
    const response = await fetchImpl(url, {
        method: "GET",
        headers,
    });
    if (!response.ok) {
        throw new Error(`Failed to fetch blog posts (status ${response.status})`);
    }
    return response.json();
};
exports.getBlogList = getBlogList;
const getBlogPost = async (idOrHandle, options = {}) => {
    const path = `${DEFAULT_ENDPOINT}/${idOrHandle}`;
    const clientRequest = (0, base_client_1.getClientRequest)(options.client);
    if (clientRequest) {
        const headers = (0, base_client_1.buildHeaders)(options);
        return (await clientRequest(path, {
            method: "GET",
            headers,
        }));
    }
    const fetchImpl = options.fetchImpl ?? globalThis.fetch;
    const url = `${(0, base_client_1.normalizeBaseUrl)(options.baseUrl)}${path}`;
    const headers = (0, base_client_1.buildHeaders)(options);
    const response = await fetchImpl(url, {
        method: "GET",
        headers,
    });
    if (!response.ok) {
        throw new Error(`Failed to fetch blog post (status ${response.status})`);
    }
    return response.json();
};
exports.getBlogPost = getBlogPost;
const getBlogMetadata = (post) => {
    return {
        title: post.title,
        description: post.short_description || "",
        openGraph: {
            title: post.title,
            description: post.short_description || "",
            images: post.thumbnail ? [{ url: post.thumbnail }] : [],
            type: "article",
            article: {
                publishedTime: post.created_at,
                modifiedTime: post.updated_at,
                authors: post.created_by ? [post.created_by] : [],
                tags: post.tags || [],
            },
        },
        twitter: {
            card: "summary_large_image",
            title: post.title,
            description: post.short_description || "",
            images: post.thumbnail ? [post.thumbnail] : [],
        },
    };
};
exports.getBlogMetadata = getBlogMetadata;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmxvZy1wb3N0cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9oZWxwZXJzL2Jsb2ctcG9zdHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsK0NBS3NCO0FBa0N0QixNQUFNLGdCQUFnQixHQUFHLG1CQUFtQixDQUFBO0FBRXJDLE1BQU0sV0FBVyxHQUFHLEtBQUssRUFDNUIsU0FBeUIsRUFBRSxFQUMzQixVQUFrQyxFQUFFLEVBQ1gsRUFBRTtJQUMzQixNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsUUFBUSxJQUFJLGdCQUFnQixDQUFBO0lBQ3BELE1BQU0sS0FBSyxHQUFHLElBQUksZUFBZSxFQUFFLENBQUE7SUFDbkMsSUFBSSxNQUFNLENBQUMsSUFBSTtRQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQTtJQUM3RCxJQUFJLE1BQU0sQ0FBQyxJQUFJO1FBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFBO0lBRTdELE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQTtJQUNwQyxNQUFNLElBQUksR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUE7SUFFbEUsTUFBTSxhQUFhLEdBQUcsSUFBQSw4QkFBZ0IsRUFBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDdEQsSUFBSSxhQUFhLEVBQUUsQ0FBQztRQUNoQixNQUFNLE9BQU8sR0FBRyxJQUFBLDBCQUFZLEVBQUMsT0FBTyxDQUFDLENBQUE7UUFDckMsT0FBTyxDQUFDLE1BQU0sYUFBYSxDQUFDLElBQUksRUFBRTtZQUM5QixNQUFNLEVBQUUsS0FBSztZQUNiLE9BQU87U0FDVixDQUFDLENBQXFCLENBQUE7SUFDM0IsQ0FBQztJQUVELE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQTtJQUN2RCxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUEsOEJBQWdCLEVBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFBO0lBQ3pELE1BQU0sT0FBTyxHQUFHLElBQUEsMEJBQVksRUFBQyxPQUFPLENBQUMsQ0FBQTtJQUVyQyxNQUFNLFFBQVEsR0FBRyxNQUFNLFNBQVMsQ0FBQyxHQUFHLEVBQUU7UUFDbEMsTUFBTSxFQUFFLEtBQUs7UUFDYixPQUFPO0tBQ1YsQ0FBQyxDQUFBO0lBRUYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsc0NBQXNDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFBO0lBQzdFLENBQUM7SUFFRCxPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtBQUMxQixDQUFDLENBQUE7QUFuQ1ksUUFBQSxXQUFXLGVBbUN2QjtBQUVNLE1BQU0sV0FBVyxHQUFHLEtBQUssRUFDNUIsVUFBa0IsRUFDbEIsVUFBa0MsRUFBRSxFQUNYLEVBQUU7SUFDM0IsTUFBTSxJQUFJLEdBQUcsR0FBRyxnQkFBZ0IsSUFBSSxVQUFVLEVBQUUsQ0FBQTtJQUVoRCxNQUFNLGFBQWEsR0FBRyxJQUFBLDhCQUFnQixFQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUN0RCxJQUFJLGFBQWEsRUFBRSxDQUFDO1FBQ2hCLE1BQU0sT0FBTyxHQUFHLElBQUEsMEJBQVksRUFBQyxPQUFPLENBQUMsQ0FBQTtRQUNyQyxPQUFPLENBQUMsTUFBTSxhQUFhLENBQUMsSUFBSSxFQUFFO1lBQzlCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsT0FBTztTQUNWLENBQUMsQ0FBcUIsQ0FBQTtJQUMzQixDQUFDO0lBRUQsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLFNBQVMsSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFBO0lBQ3ZELE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBQSw4QkFBZ0IsRUFBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUE7SUFDekQsTUFBTSxPQUFPLEdBQUcsSUFBQSwwQkFBWSxFQUFDLE9BQU8sQ0FBQyxDQUFBO0lBRXJDLE1BQU0sUUFBUSxHQUFHLE1BQU0sU0FBUyxDQUFDLEdBQUcsRUFBRTtRQUNsQyxNQUFNLEVBQUUsS0FBSztRQUNiLE9BQU87S0FDVixDQUFDLENBQUE7SUFFRixJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQ0FBcUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUE7SUFDNUUsQ0FBQztJQUVELE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFBO0FBQzFCLENBQUMsQ0FBQTtBQTdCWSxRQUFBLFdBQVcsZUE2QnZCO0FBRU0sTUFBTSxlQUFlLEdBQUcsQ0FBQyxJQUFjLEVBQUUsRUFBRTtJQUM5QyxPQUFPO1FBQ0gsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO1FBQ2pCLFdBQVcsRUFBRSxJQUFJLENBQUMsaUJBQWlCLElBQUksRUFBRTtRQUN6QyxTQUFTLEVBQUU7WUFDUCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsV0FBVyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsSUFBSSxFQUFFO1lBQ3pDLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3ZELElBQUksRUFBRSxTQUFTO1lBQ2YsT0FBTyxFQUFFO2dCQUNMLGFBQWEsRUFBRSxJQUFJLENBQUMsVUFBVTtnQkFDOUIsWUFBWSxFQUFFLElBQUksQ0FBQyxVQUFVO2dCQUM3QixPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ2pELElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUU7YUFDeEI7U0FDSjtRQUNELE9BQU8sRUFBRTtZQUNMLElBQUksRUFBRSxxQkFBcUI7WUFDM0IsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ2pCLFdBQVcsRUFBRSxJQUFJLENBQUMsaUJBQWlCLElBQUksRUFBRTtZQUN6QyxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7U0FDakQ7S0FDSixDQUFBO0FBQ0wsQ0FBQyxDQUFBO0FBdkJZLFFBQUEsZUFBZSxtQkF1QjNCIn0=