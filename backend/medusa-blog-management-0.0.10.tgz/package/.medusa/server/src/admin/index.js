"use strict";
const jsxRuntime = require("react/jsx-runtime");
const ui = require("@medusajs/ui");
const reactQuery = require("@tanstack/react-query");
const reactRouterDom = require("react-router-dom");
const icons = require("@medusajs/icons");
const adminSdk = require("@medusajs/admin-sdk");
const react = require("react");
const react$1 = require("@tiptap/react");
const StarterKit = require("@tiptap/starter-kit");
const Image = require("@tiptap/extension-image");
const Youtube = require("@tiptap/extension-youtube");
const Placeholder = require("@tiptap/extension-placeholder");
const _interopDefault = (e) => e && e.__esModule ? e : { default: e };
const StarterKit__default = /* @__PURE__ */ _interopDefault(StarterKit);
const Image__default = /* @__PURE__ */ _interopDefault(Image);
const Youtube__default = /* @__PURE__ */ _interopDefault(Youtube);
const Placeholder__default = /* @__PURE__ */ _interopDefault(Placeholder);
const BlogListingPage = () => {
  const queryClient = reactQuery.useQueryClient();
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["blog_posts"],
    queryFn: async () => {
      const res = await fetch("/admin/blog-posts");
      if (!res.ok) throw new Error("Failed to fetch posts");
      return res.json();
    }
  });
  const posts = (data == null ? void 0 : data.posts) || [];
  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this post?")) return;
    try {
      const res = await fetch(`/admin/blog-posts/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
      await queryClient.invalidateQueries({ queryKey: ["blog_posts"] });
    } catch (e) {
      const message = e instanceof Error ? e.message : "Failed to delete post";
      ui.toast.error(message);
    }
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex justify-between items-center mb-6", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h1", children: "Blog Posts" }),
      /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Link, { to: "/blog/create", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { children: "Create Post" }) })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs(ui.Table, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Title" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Status" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Author" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Created At" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Reads" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Actions" })
      ] }) }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Body, { children: isLoading ? /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Row, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: "Loading..." }) }) : posts.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Row, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: "No posts found." }) }) : posts.map((post) => /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: post.title }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { color: post.status === "published" ? "green" : "grey", children: post.status }) }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: post.created_by || "-" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: new Date(post.created_at).toLocaleDateString() }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: post.read_count }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Cell, { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Link, { to: `/blog/${post.id}`, children: /* @__PURE__ */ jsxRuntime.jsx(ui.IconButton, { variant: "transparent", children: /* @__PURE__ */ jsxRuntime.jsx(icons.PencilSquare, {}) }) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.IconButton, { variant: "transparent", onClick: () => handleDelete(post.id), children: /* @__PURE__ */ jsxRuntime.jsx(icons.Trash, { className: "text-ui-fg-error" }) })
        ] })
      ] }, post.id)) })
    ] })
  ] });
};
const config$1 = adminSdk.defineRouteConfig({
  label: "Blog",
  icon: icons.PencilSquare
});
const RichTextEditor = ({ content, onChange, placeholder = "Write something..." }) => {
  const fileInputRef = react.useRef(null);
  const editor = react$1.useEditor({
    extensions: [
      StarterKit__default.default,
      Image__default.default,
      Youtube__default.default,
      Placeholder__default.default.configure({
        placeholder
      })
    ],
    content,
    onUpdate: ({ editor: editor2 }) => {
      onChange(editor2.getHTML());
    },
    editorProps: {
      attributes: {
        class: "focus:outline-none min-h-[150px]"
      }
    }
  });
  react.useEffect(() => {
    if (editor && content !== editor.getHTML()) {
      editor.commands.setContent(content);
    }
  }, [content, editor]);
  if (!editor) {
    return null;
  }
  const handleFileUpload = async (e) => {
    var _a;
    const file = (_a = e.target.files) == null ? void 0 : _a[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("files", file);
    try {
      const res = await fetch("/admin/uploads", {
        method: "POST",
        body: formData
      });
      if (!res.ok) throw new Error("Failed to upload image");
      const responseData = await res.json();
      const uploads = responseData.uploads || responseData.files;
      if (uploads && uploads.length > 0) {
        editor.chain().focus().setImage({ src: uploads[0].url }).run();
        ui.toast.success("Image uploaded successfully");
      }
    } catch (error) {
      console.error("Upload error:", error);
      ui.toast.error("Failed to upload image");
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };
  const addImage = (e) => {
    var _a;
    e.preventDefault();
    e.stopPropagation();
    (_a = fileInputRef.current) == null ? void 0 : _a.click();
  };
  const addYoutube = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const url = window.prompt("Enter YouTube URL");
    if (url) {
      editor.commands.setYoutubeVideo({ src: url });
    }
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(
    "div",
    {
      className: "flex flex-col w-full border border-ui-border-base rounded-md overflow-hidden bg-ui-bg-component transition-colors focus-within:border-ui-border-interactive",
      onClick: () => editor.chain().focus().run(),
      children: [
        /* @__PURE__ */ jsxRuntime.jsx(
          "input",
          {
            type: "file",
            ref: fileInputRef,
            className: "hidden",
            accept: "image/*",
            onChange: handleFileUpload
          }
        ),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-1 p-2 border-b border-ui-border-base bg-ui-bg-subtle", children: [
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("bold") ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleBold().run();
              },
              children: /* @__PURE__ */ jsxRuntime.jsx("span", { className: "font-bold", children: "B" })
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("italic") ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleItalic().run();
              },
              children: /* @__PURE__ */ jsxRuntime.jsx("span", { className: "italic", children: "I" })
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("heading", { level: 1 }) ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleHeading({ level: 1 }).run();
              },
              children: /* @__PURE__ */ jsxRuntime.jsx("span", { className: "font-bold", children: "H1" })
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("heading", { level: 2 }) ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleHeading({ level: 2 }).run();
              },
              children: /* @__PURE__ */ jsxRuntime.jsx("span", { className: "font-bold", children: "H2" })
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("bulletList") ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleBulletList().run();
              },
              children: /* @__PURE__ */ jsxRuntime.jsx(icons.ListBullet, {})
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx("div", { className: "w-px h-4 bg-ui-border-base mx-1" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.IconButton, { type: "button", size: "small", variant: "transparent", onClick: addImage, children: /* @__PURE__ */ jsxRuntime.jsx(icons.Photo, {}) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.IconButton, { type: "button", size: "small", variant: "transparent", onClick: addYoutube, children: /* @__PURE__ */ jsxRuntime.jsx(icons.TriangleRightMini, {}) })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx("div", { className: "p-4 prose prose-sm max-w-none dark:prose-invert min-h-[200px] cursor-text", children: /* @__PURE__ */ jsxRuntime.jsx(react$1.EditorContent, { editor }) })
      ]
    }
  );
};
const defaultValues = {
  title: "",
  thumbnail: "",
  short_description: "",
  read_time: 0,
  tags: [],
  body: "",
  created_by: "",
  status: "draft"
};
function normalizeTags(tags) {
  if (Array.isArray(tags)) {
    return tags.filter((t) => typeof t === "string");
  }
  if (tags && typeof tags === "object" && !Array.isArray(tags)) {
    return Object.values(tags).filter((t) => typeof t === "string");
  }
  return [];
}
const BlogForm = ({ initialValues, onSubmit, isLoading }) => {
  const [formData, setFormData] = react.useState(() => {
    if (!initialValues) return { ...defaultValues };
    const status = initialValues.status === "published" ? "published" : "draft";
    return {
      title: initialValues.title ?? defaultValues.title,
      thumbnail: initialValues.thumbnail ?? defaultValues.thumbnail,
      short_description: initialValues.short_description ?? defaultValues.short_description,
      read_time: typeof initialValues.read_time === "number" && !Number.isNaN(initialValues.read_time) ? initialValues.read_time : defaultValues.read_time,
      tags: normalizeTags(initialValues.tags),
      body: initialValues.body ?? defaultValues.body,
      created_by: initialValues.created_by ?? defaultValues.created_by,
      status
    };
  });
  const [isUploading, setIsUploading] = react.useState(false);
  const [tagInput, setTagInput] = react.useState("");
  const handleChange = (key, value) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };
  const setStatus = (status) => {
    setFormData((prev) => ({ ...prev, status }));
  };
  const handleAddTag = () => {
    if (tagInput.trim()) {
      setFormData((prev) => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput("");
    }
  };
  const handleRemoveTag = (index) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((_, i) => i !== index)
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };
  return /* @__PURE__ */ jsxRuntime.jsxs("form", { onSubmit: handleSubmit, className: "flex flex-col gap-6", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "rounded-lg border border-ui-border-base bg-ui-bg-subtle p-4 flex flex-col gap-3", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { className: "text-ui-fg-base font-medium", children: "Publish status" }),
      /* @__PURE__ */ jsxRuntime.jsx("p", { className: "text-ui-fg-subtle text-small", children: formData.status === "published" ? "This post is visible on the store. Switch to Draft to hide it." : "This post is a draft and not visible on the store. Publish to make it visible." }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            type: "button",
            variant: formData.status === "draft" ? "primary" : "secondary",
            onClick: () => setStatus("draft"),
            size: "large",
            children: "Draft"
          }
        ),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            type: "button",
            variant: formData.status === "published" ? "primary" : "secondary",
            onClick: () => setStatus("published"),
            size: "large",
            children: "Published"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Title" }),
      /* @__PURE__ */ jsxRuntime.jsx(
        ui.Input,
        {
          placeholder: "Blog Title",
          value: formData.title,
          onChange: (e) => handleChange("title", e.target.value),
          required: true
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Thumbnail" }),
      formData.thumbnail && /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "relative w-full aspect-video rounded-lg overflow-hidden border border-ui-border-base group", children: [
        /* @__PURE__ */ jsxRuntime.jsx(
          "img",
          {
            src: formData.thumbnail,
            alt: "Thumbnail",
            className: "w-full h-full object-cover"
          }
        ),
        /* @__PURE__ */ jsxRuntime.jsx("div", { className: "absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center", children: /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            variant: "danger",
            type: "button",
            onClick: () => handleChange("thumbnail", ""),
            children: "Remove"
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxRuntime.jsx(
        ui.Input,
        {
          type: "file",
          accept: "image/*",
          disabled: isUploading,
          onChange: async (e) => {
            var _a;
            const file = (_a = e.target.files) == null ? void 0 : _a[0];
            if (!file) return;
            const formData2 = new FormData();
            formData2.append("files", file);
            setIsUploading(true);
            try {
              const res = await fetch("/admin/uploads", {
                method: "POST",
                body: formData2
              });
              if (!res.ok) throw new Error("Failed to upload image");
              const responseData = await res.json();
              const uploads = responseData.uploads || responseData.files;
              if (uploads && uploads.length > 0) {
                handleChange("thumbnail", uploads[0].url);
                ui.toast.success("Image uploaded successfully");
              }
            } catch (error) {
              console.error("Upload error:", error);
              ui.toast.error("Failed to upload image");
            } finally {
              setIsUploading(false);
            }
          }
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Short Description" }),
      /* @__PURE__ */ jsxRuntime.jsx(
        ui.Textarea,
        {
          placeholder: "Brief summary...",
          value: formData.short_description,
          onChange: (e) => handleChange("short_description", e.target.value)
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Read Time (Seconds)" }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Input,
          {
            type: "number",
            min: 0,
            value: formData.read_time,
            onChange: (e) => {
              const n = parseInt(e.target.value, 10);
              handleChange("read_time", Number.isNaN(n) ? 0 : n);
            }
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Author Name" }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Input,
          {
            placeholder: "John Doe",
            value: formData.created_by,
            onChange: (e) => handleChange("created_by", e.target.value)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Tags (Meta only)" }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Input,
          {
            value: tagInput,
            onChange: (e) => setTagInput(e.target.value),
            placeholder: "Add a tag...",
            onKeyDown: (e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleAddTag();
              }
            }
          }
        ),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { type: "button", variant: "secondary", onClick: handleAddTag, children: "Add" })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex gap-2 flex-wrap", children: formData.tags.map((tag, i) => /* @__PURE__ */ jsxRuntime.jsxs("span", { className: "bg-ui-bg-subtle text-ui-fg-subtle px-2 py-1 rounded text-small flex items-center gap-1", children: [
        tag,
        /* @__PURE__ */ jsxRuntime.jsx("button", { type: "button", onClick: () => handleRemoveTag(i), children: "×" })
      ] }, i)) })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Content" }),
      /* @__PURE__ */ jsxRuntime.jsx(
        RichTextEditor,
        {
          content: formData.body,
          onChange: (content) => handleChange("body", content)
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex justify-end gap-2", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { type: "submit", isLoading, children: "Save Post" }) })
  ] });
};
const BlogEditPage = () => {
  const { id } = reactRouterDom.useParams();
  const navigate = reactRouterDom.useNavigate();
  const queryClient = reactQuery.useQueryClient();
  const [isLoading, setIsLoading] = react.useState(false);
  const { data, isLoading: isFetching } = reactQuery.useQuery({
    queryKey: ["blog_posts", id],
    queryFn: async () => {
      const res = await fetch(`/admin/blog-posts/${id}`);
      if (!res.ok) throw new Error("Failed to fetch post");
      return res.json();
    },
    enabled: !!id
  });
  const post = data == null ? void 0 : data.post;
  const handleSubmit = async (values) => {
    setIsLoading(true);
    try {
      const res = await fetch(`/admin/blog-posts/${id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(values)
      });
      if (!res.ok) throw new Error("Failed to update post");
      ui.toast.success("Post updated successfully");
      await queryClient.invalidateQueries({ queryKey: ["blog_posts"] });
      if (id) await queryClient.invalidateQueries({ queryKey: ["blog_posts", id] });
      navigate("/blog");
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : "Failed to update post";
      ui.toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };
  if (!id) {
    return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { children: "Invalid post ID" });
  }
  if (isFetching) {
    return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { children: "Loading..." });
  }
  if (!post) {
    return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { children: "Post not found" });
  }
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { children: [
    /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h1", className: "mb-6", children: "Edit Blog Post" }),
    /* @__PURE__ */ jsxRuntime.jsx(
      BlogForm,
      {
        initialValues: post,
        onSubmit: handleSubmit,
        isLoading
      },
      id
    )
  ] });
};
const BlogCreatePage = () => {
  const navigate = reactRouterDom.useNavigate();
  const queryClient = reactQuery.useQueryClient();
  const [isLoading, setIsLoading] = react.useState(false);
  const handleSubmit = async (values) => {
    setIsLoading(true);
    try {
      const res = await fetch("/admin/blog-posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(values)
      });
      if (!res.ok) throw new Error("Failed to create post");
      ui.toast.success("Post created successfully");
      await queryClient.invalidateQueries({ queryKey: ["blog_posts"] });
      navigate("/blog");
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : "Failed to create post";
      ui.toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { children: [
    /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h1", className: "mb-6", children: "Create New Blog Post" }),
    /* @__PURE__ */ jsxRuntime.jsx(BlogForm, { onSubmit: handleSubmit, isLoading })
  ] });
};
const config = adminSdk.defineRouteConfig({
  label: "Create Post"
});
const i18nTranslations0 = {};
const widgetModule = { widgets: [] };
const routeModule = {
  routes: [
    {
      Component: BlogListingPage,
      path: "/blog"
    },
    {
      Component: BlogEditPage,
      path: "/blog/:id"
    },
    {
      Component: BlogCreatePage,
      path: "/blog/create"
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config$1.label,
      icon: config$1.icon,
      path: "/blog",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config.label,
      icon: void 0,
      path: "/blog/create",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: i18nTranslations0 };
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule
};
module.exports = plugin;
