import { jsxs, jsx } from "react/jsx-runtime";
import { Container, Heading, Button, Table, Badge, IconButton, toast, Label, Input, Textarea } from "@medusajs/ui";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { Link, useParams, useNavigate } from "react-router-dom";
import { PencilSquare, Trash, ListBullet, Photo, TriangleRightMini } from "@medusajs/icons";
import { defineRouteConfig } from "@medusajs/admin-sdk";
import { useRef, useEffect, useState } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Image from "@tiptap/extension-image";
import Youtube from "@tiptap/extension-youtube";
import Placeholder from "@tiptap/extension-placeholder";
const BlogListingPage = () => {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["blog_posts"],
    queryFn: async () => {
      const res = await fetch("/admin/blog-posts");
      if (!res.ok) throw new Error("Failed to fetch posts");
      return res.json();
    }
  });
  const posts = (data == null ? void 0 : data.posts) || [];
  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this post?")) return;
    try {
      const res = await fetch(`/admin/blog-posts/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
      await queryClient.invalidateQueries({ queryKey: ["blog_posts"] });
    } catch (e) {
      const message = e instanceof Error ? e.message : "Failed to delete post";
      toast.error(message);
    }
  };
  return /* @__PURE__ */ jsxs(Container, { children: [
    /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center mb-6", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h1", children: "Blog Posts" }),
      /* @__PURE__ */ jsx(Link, { to: "/blog/create", children: /* @__PURE__ */ jsx(Button, { children: "Create Post" }) })
    ] }),
    /* @__PURE__ */ jsxs(Table, { children: [
      /* @__PURE__ */ jsx(Table.Header, { children: /* @__PURE__ */ jsxs(Table.Row, { children: [
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Title" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Status" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Author" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Created At" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Reads" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Actions" })
      ] }) }),
      /* @__PURE__ */ jsx(Table.Body, { children: isLoading ? /* @__PURE__ */ jsx(Table.Row, { children: /* @__PURE__ */ jsx(Table.Cell, { children: "Loading..." }) }) : posts.length === 0 ? /* @__PURE__ */ jsx(Table.Row, { children: /* @__PURE__ */ jsx(Table.Cell, { children: "No posts found." }) }) : posts.map((post) => /* @__PURE__ */ jsxs(Table.Row, { children: [
        /* @__PURE__ */ jsx(Table.Cell, { children: post.title }),
        /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx(Badge, { color: post.status === "published" ? "green" : "grey", children: post.status }) }),
        /* @__PURE__ */ jsx(Table.Cell, { children: post.created_by || "-" }),
        /* @__PURE__ */ jsx(Table.Cell, { children: new Date(post.created_at).toLocaleDateString() }),
        /* @__PURE__ */ jsx(Table.Cell, { children: post.read_count }),
        /* @__PURE__ */ jsxs(Table.Cell, { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx(Link, { to: `/blog/${post.id}`, children: /* @__PURE__ */ jsx(IconButton, { variant: "transparent", children: /* @__PURE__ */ jsx(PencilSquare, {}) }) }),
          /* @__PURE__ */ jsx(IconButton, { variant: "transparent", onClick: () => handleDelete(post.id), children: /* @__PURE__ */ jsx(Trash, { className: "text-ui-fg-error" }) })
        ] })
      ] }, post.id)) })
    ] })
  ] });
};
const config$1 = defineRouteConfig({
  label: "Blog",
  icon: PencilSquare
});
const RichTextEditor = ({ content, onChange, placeholder = "Write something..." }) => {
  const fileInputRef = useRef(null);
  const editor = useEditor({
    extensions: [
      StarterKit,
      Image,
      Youtube,
      Placeholder.configure({
        placeholder
      })
    ],
    content,
    onUpdate: ({ editor: editor2 }) => {
      onChange(editor2.getHTML());
    },
    editorProps: {
      attributes: {
        class: "focus:outline-none min-h-[150px]"
      }
    }
  });
  useEffect(() => {
    if (editor && content !== editor.getHTML()) {
      editor.commands.setContent(content);
    }
  }, [content, editor]);
  if (!editor) {
    return null;
  }
  const handleFileUpload = async (e) => {
    var _a;
    const file = (_a = e.target.files) == null ? void 0 : _a[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("files", file);
    try {
      const res = await fetch("/admin/uploads", {
        method: "POST",
        body: formData
      });
      if (!res.ok) throw new Error("Failed to upload image");
      const responseData = await res.json();
      const uploads = responseData.uploads || responseData.files;
      if (uploads && uploads.length > 0) {
        editor.chain().focus().setImage({ src: uploads[0].url }).run();
        toast.success("Image uploaded successfully");
      }
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("Failed to upload image");
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };
  const addImage = (e) => {
    var _a;
    e.preventDefault();
    e.stopPropagation();
    (_a = fileInputRef.current) == null ? void 0 : _a.click();
  };
  const addYoutube = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const url = window.prompt("Enter YouTube URL");
    if (url) {
      editor.commands.setYoutubeVideo({ src: url });
    }
  };
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "flex flex-col w-full border border-ui-border-base rounded-md overflow-hidden bg-ui-bg-component transition-colors focus-within:border-ui-border-interactive",
      onClick: () => editor.chain().focus().run(),
      children: [
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "file",
            ref: fileInputRef,
            className: "hidden",
            accept: "image/*",
            onChange: handleFileUpload
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 p-2 border-b border-ui-border-base bg-ui-bg-subtle", children: [
          /* @__PURE__ */ jsx(
            IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("bold") ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleBold().run();
              },
              children: /* @__PURE__ */ jsx("span", { className: "font-bold", children: "B" })
            }
          ),
          /* @__PURE__ */ jsx(
            IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("italic") ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleItalic().run();
              },
              children: /* @__PURE__ */ jsx("span", { className: "italic", children: "I" })
            }
          ),
          /* @__PURE__ */ jsx(
            IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("heading", { level: 1 }) ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleHeading({ level: 1 }).run();
              },
              children: /* @__PURE__ */ jsx("span", { className: "font-bold", children: "H1" })
            }
          ),
          /* @__PURE__ */ jsx(
            IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("heading", { level: 2 }) ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleHeading({ level: 2 }).run();
              },
              children: /* @__PURE__ */ jsx("span", { className: "font-bold", children: "H2" })
            }
          ),
          /* @__PURE__ */ jsx(
            IconButton,
            {
              type: "button",
              size: "small",
              variant: editor.isActive("bulletList") ? "primary" : "transparent",
              onClick: (e) => {
                e.preventDefault();
                e.stopPropagation();
                editor.chain().focus().toggleBulletList().run();
              },
              children: /* @__PURE__ */ jsx(ListBullet, {})
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "w-px h-4 bg-ui-border-base mx-1" }),
          /* @__PURE__ */ jsx(IconButton, { type: "button", size: "small", variant: "transparent", onClick: addImage, children: /* @__PURE__ */ jsx(Photo, {}) }),
          /* @__PURE__ */ jsx(IconButton, { type: "button", size: "small", variant: "transparent", onClick: addYoutube, children: /* @__PURE__ */ jsx(TriangleRightMini, {}) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "p-4 prose prose-sm max-w-none dark:prose-invert min-h-[200px] cursor-text", children: /* @__PURE__ */ jsx(EditorContent, { editor }) })
      ]
    }
  );
};
const defaultValues = {
  title: "",
  thumbnail: "",
  short_description: "",
  read_time: 0,
  tags: [],
  body: "",
  created_by: "",
  status: "draft"
};
function normalizeTags(tags) {
  if (Array.isArray(tags)) {
    return tags.filter((t) => typeof t === "string");
  }
  if (tags && typeof tags === "object" && !Array.isArray(tags)) {
    return Object.values(tags).filter((t) => typeof t === "string");
  }
  return [];
}
const BlogForm = ({ initialValues, onSubmit, isLoading }) => {
  const [formData, setFormData] = useState(() => {
    if (!initialValues) return { ...defaultValues };
    const status = initialValues.status === "published" ? "published" : "draft";
    return {
      title: initialValues.title ?? defaultValues.title,
      thumbnail: initialValues.thumbnail ?? defaultValues.thumbnail,
      short_description: initialValues.short_description ?? defaultValues.short_description,
      read_time: typeof initialValues.read_time === "number" && !Number.isNaN(initialValues.read_time) ? initialValues.read_time : defaultValues.read_time,
      tags: normalizeTags(initialValues.tags),
      body: initialValues.body ?? defaultValues.body,
      created_by: initialValues.created_by ?? defaultValues.created_by,
      status
    };
  });
  const [isUploading, setIsUploading] = useState(false);
  const [tagInput, setTagInput] = useState("");
  const handleChange = (key, value) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };
  const setStatus = (status) => {
    setFormData((prev) => ({ ...prev, status }));
  };
  const handleAddTag = () => {
    if (tagInput.trim()) {
      setFormData((prev) => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput("");
    }
  };
  const handleRemoveTag = (index) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((_, i) => i !== index)
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };
  return /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "flex flex-col gap-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-ui-border-base bg-ui-bg-subtle p-4 flex flex-col gap-3", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-ui-fg-base font-medium", children: "Publish status" }),
      /* @__PURE__ */ jsx("p", { className: "text-ui-fg-subtle text-small", children: formData.status === "published" ? "This post is visible on the store. Switch to Draft to hide it." : "This post is a draft and not visible on the store. Publish to make it visible." }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx(
          Button,
          {
            type: "button",
            variant: formData.status === "draft" ? "primary" : "secondary",
            onClick: () => setStatus("draft"),
            size: "large",
            children: "Draft"
          }
        ),
        /* @__PURE__ */ jsx(
          Button,
          {
            type: "button",
            variant: formData.status === "published" ? "primary" : "secondary",
            onClick: () => setStatus("published"),
            size: "large",
            children: "Published"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsx(Label, { children: "Title" }),
      /* @__PURE__ */ jsx(
        Input,
        {
          placeholder: "Blog Title",
          value: formData.title,
          onChange: (e) => handleChange("title", e.target.value),
          required: true
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsx(Label, { children: "Thumbnail" }),
      formData.thumbnail && /* @__PURE__ */ jsxs("div", { className: "relative w-full aspect-video rounded-lg overflow-hidden border border-ui-border-base group", children: [
        /* @__PURE__ */ jsx(
          "img",
          {
            src: formData.thumbnail,
            alt: "Thumbnail",
            className: "w-full h-full object-cover"
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center", children: /* @__PURE__ */ jsx(
          Button,
          {
            variant: "danger",
            type: "button",
            onClick: () => handleChange("thumbnail", ""),
            children: "Remove"
          }
        ) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsx(
        Input,
        {
          type: "file",
          accept: "image/*",
          disabled: isUploading,
          onChange: async (e) => {
            var _a;
            const file = (_a = e.target.files) == null ? void 0 : _a[0];
            if (!file) return;
            const formData2 = new FormData();
            formData2.append("files", file);
            setIsUploading(true);
            try {
              const res = await fetch("/admin/uploads", {
                method: "POST",
                body: formData2
              });
              if (!res.ok) throw new Error("Failed to upload image");
              const responseData = await res.json();
              const uploads = responseData.uploads || responseData.files;
              if (uploads && uploads.length > 0) {
                handleChange("thumbnail", uploads[0].url);
                toast.success("Image uploaded successfully");
              }
            } catch (error) {
              console.error("Upload error:", error);
              toast.error("Failed to upload image");
            } finally {
              setIsUploading(false);
            }
          }
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsx(Label, { children: "Short Description" }),
      /* @__PURE__ */ jsx(
        Textarea,
        {
          placeholder: "Brief summary...",
          value: formData.short_description,
          onChange: (e) => handleChange("short_description", e.target.value)
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Read Time (Seconds)" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            type: "number",
            min: 0,
            value: formData.read_time,
            onChange: (e) => {
              const n = parseInt(e.target.value, 10);
              handleChange("read_time", Number.isNaN(n) ? 0 : n);
            }
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Author Name" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            placeholder: "John Doe",
            value: formData.created_by,
            onChange: (e) => handleChange("created_by", e.target.value)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsx(Label, { children: "Tags (Meta only)" }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx(
          Input,
          {
            value: tagInput,
            onChange: (e) => setTagInput(e.target.value),
            placeholder: "Add a tag...",
            onKeyDown: (e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleAddTag();
              }
            }
          }
        ),
        /* @__PURE__ */ jsx(Button, { type: "button", variant: "secondary", onClick: handleAddTag, children: "Add" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex gap-2 flex-wrap", children: formData.tags.map((tag, i) => /* @__PURE__ */ jsxs("span", { className: "bg-ui-bg-subtle text-ui-fg-subtle px-2 py-1 rounded text-small flex items-center gap-1", children: [
        tag,
        /* @__PURE__ */ jsx("button", { type: "button", onClick: () => handleRemoveTag(i), children: "×" })
      ] }, i)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsx(Label, { children: "Content" }),
      /* @__PURE__ */ jsx(
        RichTextEditor,
        {
          content: formData.body,
          onChange: (content) => handleChange("body", content)
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex justify-end gap-2", children: /* @__PURE__ */ jsx(Button, { type: "submit", isLoading, children: "Save Post" }) })
  ] });
};
const BlogEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isLoading, setIsLoading] = useState(false);
  const { data, isLoading: isFetching } = useQuery({
    queryKey: ["blog_posts", id],
    queryFn: async () => {
      const res = await fetch(`/admin/blog-posts/${id}`);
      if (!res.ok) throw new Error("Failed to fetch post");
      return res.json();
    },
    enabled: !!id
  });
  const post = data == null ? void 0 : data.post;
  const handleSubmit = async (values) => {
    setIsLoading(true);
    try {
      const res = await fetch(`/admin/blog-posts/${id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(values)
      });
      if (!res.ok) throw new Error("Failed to update post");
      toast.success("Post updated successfully");
      await queryClient.invalidateQueries({ queryKey: ["blog_posts"] });
      if (id) await queryClient.invalidateQueries({ queryKey: ["blog_posts", id] });
      navigate("/blog");
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : "Failed to update post";
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };
  if (!id) {
    return /* @__PURE__ */ jsx(Container, { children: "Invalid post ID" });
  }
  if (isFetching) {
    return /* @__PURE__ */ jsx(Container, { children: "Loading..." });
  }
  if (!post) {
    return /* @__PURE__ */ jsx(Container, { children: "Post not found" });
  }
  return /* @__PURE__ */ jsxs(Container, { children: [
    /* @__PURE__ */ jsx(Heading, { level: "h1", className: "mb-6", children: "Edit Blog Post" }),
    /* @__PURE__ */ jsx(
      BlogForm,
      {
        initialValues: post,
        onSubmit: handleSubmit,
        isLoading
      },
      id
    )
  ] });
};
const BlogCreatePage = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isLoading, setIsLoading] = useState(false);
  const handleSubmit = async (values) => {
    setIsLoading(true);
    try {
      const res = await fetch("/admin/blog-posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(values)
      });
      if (!res.ok) throw new Error("Failed to create post");
      toast.success("Post created successfully");
      await queryClient.invalidateQueries({ queryKey: ["blog_posts"] });
      navigate("/blog");
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : "Failed to create post";
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ jsxs(Container, { children: [
    /* @__PURE__ */ jsx(Heading, { level: "h1", className: "mb-6", children: "Create New Blog Post" }),
    /* @__PURE__ */ jsx(BlogForm, { onSubmit: handleSubmit, isLoading })
  ] });
};
const config = defineRouteConfig({
  label: "Create Post"
});
const i18nTranslations0 = {};
const widgetModule = { widgets: [] };
const routeModule = {
  routes: [
    {
      Component: BlogListingPage,
      path: "/blog"
    },
    {
      Component: BlogEditPage,
      path: "/blog/:id"
    },
    {
      Component: BlogCreatePage,
      path: "/blog/create"
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config$1.label,
      icon: config$1.icon,
      path: "/blog",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config.label,
      icon: void 0,
      path: "/blog/create",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: i18nTranslations0 };
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule
};
export {
  plugin as default
};
